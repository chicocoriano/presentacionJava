package com.company;
import MisExcepciones.*; //Importo todas las excepciones del paquete MisExcepciones

public class clase {

    public void g() throws MiExcepcion{
        throw new MiExcepcion("Estoy lanzando esta excepcion");
    }

    public void f() throws MiExcepcion2 {
        try {
            g();
        } catch (MiExcepcion e) {
            throw new MiExcepcion2("Estoy lanzando otra excepcion");
        }
    }

}
