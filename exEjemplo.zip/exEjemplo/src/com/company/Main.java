package com.company;

/* Crear una clase con dos métodos, f( ) y g( ). En g( ), lanzar una excepción de un nuevo tipo
a definir. En f( ), invocar a g( ), capturar su excepción y, en la cláusula catch, lanzar una excepción
distinta (de tipo diferente al definido). Probar el código en un método main( ). */

import MisExcepciones.*;

public class Main {

    public static void main(String[] args) {

        try{
            clase objeto= new clase();
            objeto.f();

        }
        catch(MiExcepcion2 e){
            System.out.println("He capturado la excepcion");
        }



    }
}

