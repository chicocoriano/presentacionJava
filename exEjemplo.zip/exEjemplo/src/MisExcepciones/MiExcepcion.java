package MisExcepciones;


public class MiExcepcion extends Exception {

    public MiExcepcion(){
        super();
    }

    public MiExcepcion(String m){
        super(m);
    }

    /* Puede ser un constructor sin parámetros o con parámetros */
}
