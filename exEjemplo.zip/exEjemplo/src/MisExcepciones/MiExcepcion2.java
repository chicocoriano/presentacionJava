package MisExcepciones;

public class MiExcepcion2 extends Exception {

    public MiExcepcion2(){
        super();
    }

    public MiExcepcion2(String m){
        super(m);
    }

    // Puede ser un constructor sin parámetros o con parámetros
}
